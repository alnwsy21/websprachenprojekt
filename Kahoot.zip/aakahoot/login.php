<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metadaten für das Dokument -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- Stildefinitionen für das Aussehen der Seite -->
    <style>
        /* Allgemeine Stilregeln für den Body */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url("login3.png");
            background-size: cover;
            background-position: center;
        }

        /* Stilregeln für den Hauptcontainer */
        .container {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            overflow: hidden;
            width: 300px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
            margin-top: -130px;
        }

        /* Stilregeln für das Formular */
        form {
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Stilregeln für den Header 2 */
        h2 {
            margin-bottom: 20px;
            color: #333;
            font-size: 1.5em;
        }

        /* Stilregeln für die Eingabefelder */
        input {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: calc(100% - 20px);
            box-sizing: border-box;
        }

        /* Stilregeln für die Schaltflächen */
        button,
        .guest-button,
        .register-button,
        .leaderboard-button {
            padding: 12px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: calc(100% - 20px);
            box-sizing: border-box;
            transition: background-color 0.3s;
        }

        /* Stilregeln für Schaltflächen beim Hovern */
        button:hover,
        .guest-button:hover,
        .register-button:hover,
        .leaderboard-button:hover {
            background-color: #2980b9;
        }

        /* Zusätzliche Stilregeln für die Registrieren-Schaltfläche */
        .register-button {
            padding: 8px;
            margin-top: 10px;
        }

        /* Stilregeln für den Leaderboard-Container */
        .leaderboard-container {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            overflow: hidden;
            margin-top: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
    </style>
</head>

<body>
    <!-- Hauptcontainer für das Login-Formular -->
    <div class="container">
        <!-- Login-Formular -->
        <form id="cipherAccessForm" action="login.php" method="post">
            <h2>Login Daten!</h2>
            <input type="text" id="username" name="username" placeholder="Benutzername" required autocomplete="off">
            <input type="password" id="password" name="password" placeholder="Passwort" required>
            <button type="submit">Anmelden</button>
            <br>
            <button class="guest-button" onclick="location.href='ask.php'">Ohne Anmeldung</button>
            <button class="register-button" onclick="location.href='register.php'">Registrieren</button>
        </form>

        <!-- PHP-Code für die Verarbeitung des Logins -->
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];

            $file = fopen('login.csv', 'r');

            $loginSuccessful = false;

            while (($line = fgetcsv($file)) !== false) {
                if ($line[0] === $username && $line[1] === $password) {
                    $loginSuccessful = true;

                    if ($line[2] === 'admin') {
                        fclose($file);
                        header('Location: Edit2.php');
                        exit();
                    } elseif ($line[2] === 'user') {
                        fclose($file);
                        header('Location: ask.php');
                        exit();
                    }
                }
            }

            fclose($file);

            // Wenn der Login fehlschlägt, zeige eine Fehlermeldung
            if (!$loginSuccessful) {
                echo '<p style="color: red;">Tragen Sie bitte gültige Daten ein!</p>';
            }
        }
        ?>
    </div>

    <!-- Leaderboard-Container -->
    <div class="leaderboard-container">
        <h2>Rangliste</h2>
        <button class="leaderboard-button" onclick="showLeaderboard()">Rangliste anzeigen</button>
        <div id="leaderboard" style="margin-top: 10px;"></div>
    </div>

    <!-- JavaScript-Code für die Rangliste -->
    <script>
        function showLeaderboard() {
            const leaderboardContainer = document.getElementById("leaderboard");
            const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];

            leaderboardContainer.innerHTML = "<h3>Top 15 Rangliste</h3>";
            if (leaderboard.length > 0) {
                leaderboard.forEach((entry, index) => {
                    leaderboardContainer.innerHTML += `<p>${index + 1}. ${entry.name} - ${entry.score} von 30 (${entry.percentage.toFixed(2)}%)</p>`;
                });
            } else {
                leaderboardContainer.innerHTML += "<p>Die Rangliste ist noch leer.</p>";
            }
        }
    </script>
</body>

</html>
