﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Dress_Fine
{
    public partial class ArtikelHinzufügen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public ArtikelHinzufügen()
        {
            InitializeComponent();
            Customizedatagriedview();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void Customizedatagriedview()
        {
            //dg eigenschaften anpassen
            dghinzufügen.AllowUserToAddRows = false;
            dghinzufügen.AllowUserToDeleteRows = false;
            dghinzufügen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dghinzufügen.RowHeadersVisible = false;
            dghinzufügen.SelectionMode = DataGridViewSelectionMode.FullColumnSelect;
            dghinzufügen.MultiSelect = false;
            dghinzufügen.ReadOnly = true;
            dghinzufügen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.GridColor = Color.FromArgb(32, 32, 32);


            //zellformatierung
            dghinzufügen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.DefaultCellStyle.ForeColor = Color.Gainsboro;
            dghinzufügen.DefaultCellStyle.Font = new Font("Arial", 9);

            //kopfzeile anpassen
            dghinzufügen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.ColumnHeadersDefaultCellStyle.ForeColor = Color.Gainsboro;
            dghinzufügen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dghinzufügen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Auswahlstil
            dghinzufügen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.DefaultCellStyle.SelectionForeColor = Color.Gainsboro;

            //Alterniernde zeilenfarben
            dghinzufügen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            //Gitterlinien abzeigen
            dghinzufügen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            //scrollbar anpassen
            dghinzufügen.ScrollBars = ScrollBars.Both;
        }
        private void adjustdatagridview()
        {
            //datagridview an die größe des panels anpassen
            dghinzufügen.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dghinzufügen.Location = new Point(10, 10);
        }
        private void ArtikelHinzufügen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0;DataSource = Dress.accdb";
                con.Open();
              //  con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim Öffnung des Datenbankes" +a);
            }

            adjustdatagridview();
            datagridview();
        }
        private void datagridview()
        {
            try
            {
                con.Open();
                ds.Clear();
                ada = new OleDbDataAdapter("SELECT Artikel_id, Artikelgruppen_id, Artikel_name, Artikel_beschreibung, Artikel_einzelpreis, Artikel_menge, Artikel_verfügbar FROM Artikel", con);
                ada.Fill(ds, "Artikel");
                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Artikel";
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim anzeigen des Datagridviews!:" +a );
            }
        }
    }
}
