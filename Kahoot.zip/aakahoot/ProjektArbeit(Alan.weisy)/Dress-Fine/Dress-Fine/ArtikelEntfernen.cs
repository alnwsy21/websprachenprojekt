﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dress_Fine
{
    public partial class ArtikelEntfernen : Form
    {
        public ArtikelEntfernen()
        {
            InitializeComponent();
            Customizedatagriedview();
        }

        private void ArtikelEntfernen_Load(object sender, EventArgs e)
        {
            adjustdatagridview();
        }
        private void Customizedatagriedview()
        {
            //dg eigenschaften anpassen
            dgentfernen.AllowUserToAddRows = false;
            dgentfernen.AllowUserToDeleteRows = false;
            dgentfernen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgentfernen.RowHeadersVisible = false;
            dgentfernen.SelectionMode = DataGridViewSelectionMode.FullColumnSelect;
            dgentfernen.MultiSelect = false;
            dgentfernen.ReadOnly = true;
            dgentfernen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dgentfernen.GridColor = Color.FromArgb(32, 32, 32);


            //zellformatierung
            dgentfernen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dgentfernen.DefaultCellStyle.ForeColor = Color.Gainsboro;
            dgentfernen.DefaultCellStyle.Font = new Font("Arial", 9);

            //kopfzeile anpassen
            dgentfernen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dgentfernen.ColumnHeadersDefaultCellStyle.ForeColor = Color.Gainsboro;
            dgentfernen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial",10,FontStyle.Bold);
            dgentfernen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Auswahlstil
            dgentfernen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dgentfernen.DefaultCellStyle.SelectionForeColor = Color.Gainsboro;

            //Alterniernde zeilenfarben
            dgentfernen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            //Gitterlinien abzeigen
            dgentfernen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            //scrollbar anpassen
            dgentfernen.ScrollBars = ScrollBars.Both;
        }
        private void adjustdatagridview()
        {
            //datagridview an die größe des panels anpassen
            dgentfernen.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dgentfernen.Location = new Point(10, 10);
        }
    }
}
