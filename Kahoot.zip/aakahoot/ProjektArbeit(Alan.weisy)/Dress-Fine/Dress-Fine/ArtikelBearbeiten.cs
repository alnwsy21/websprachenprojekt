﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dress_Fine
{
    public partial class ArtikelBearbeiten : Form
    {
        public ArtikelBearbeiten()
        {
            InitializeComponent();
            Customizedatagriedview();
        }

        private void ArtikelBearbeiten_Load(object sender, EventArgs e)
        {
            adjustdatagridview();
        }
        private void Customizedatagriedview()
        {
            //dg eigenschaften anpassen
            dgbearbeiten.AllowUserToAddRows = false;
            dgbearbeiten.AllowUserToDeleteRows = false;
            dgbearbeiten.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgbearbeiten.RowHeadersVisible = false;
            dgbearbeiten.SelectionMode = DataGridViewSelectionMode.FullColumnSelect;
            dgbearbeiten.MultiSelect = false;
            dgbearbeiten.ReadOnly = true;
            dgbearbeiten.BackgroundColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.GridColor = Color.FromArgb(32, 32, 32);


            //zellformatierung
            dgbearbeiten.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.DefaultCellStyle.ForeColor = Color.Gainsboro;
            dgbearbeiten.DefaultCellStyle.Font = new Font("Arial", 9);

            //kopfzeile anpassen
            dgbearbeiten.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.ForeColor = Color.Gainsboro;
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Auswahlstil
            dgbearbeiten.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.DefaultCellStyle.SelectionForeColor = Color.Gainsboro;

            //Alterniernde zeilenfarben
            dgbearbeiten.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            //Gitterlinien abzeigen
            dgbearbeiten.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            //scrollbar anpassen
            dgbearbeiten.ScrollBars = ScrollBars.Both;
        }
        private void adjustdatagridview()
        {
            //datagridview an die größe des panels anpassen
            dgbearbeiten.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dgbearbeiten.Location = new Point(10, 10);
        }
    }
}
