﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Dress_Fine
{
    public partial class ArtikelAnzeigen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Dress.accdb";
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public ArtikelAnzeigen()
        {
            InitializeComponent();
        }

        private void ArtikelAnzeigen_Load(object sender, EventArgs e)
        {

            try
            {
                con.ConnectionString = connectionString;
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("Select * from Artikel", con);
                ada.Fill(ds, "Artikel");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "Artikel";
                con.Close();
            }
            catch (Exception a)
            {

                throw;
            }
        }
    }
}
