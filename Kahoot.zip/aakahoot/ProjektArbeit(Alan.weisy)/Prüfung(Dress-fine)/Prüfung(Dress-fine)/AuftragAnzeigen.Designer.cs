﻿
namespace Prüfung_Dress_fine_
{
    partial class AuftragAnzeigen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.dganzeigen = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dganzeigen)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(1, 646);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(778, 108);
            this.label2.TabIndex = 2;
            this.label2.Text = "Auftrag Anzeigen";
            // 
            // dganzeigen
            // 
            this.dganzeigen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dganzeigen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dganzeigen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dganzeigen.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dganzeigen.Location = new System.Drawing.Point(-3, -2);
            this.dganzeigen.Name = "dganzeigen";
            this.dganzeigen.RowHeadersVisible = false;
            this.dganzeigen.Size = new System.Drawing.Size(1216, 321);
            this.dganzeigen.TabIndex = 3;
            // 
            // AuftragAnzeigen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1215, 767);
            this.Controls.Add(this.dganzeigen);
            this.Controls.Add(this.label2);
            this.Name = "AuftragAnzeigen";
            this.Text = "AuftragAnzeigen";
            this.Load += new System.EventHandler(this.AuftragAnzeigen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dganzeigen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dganzeigen;
    }
}