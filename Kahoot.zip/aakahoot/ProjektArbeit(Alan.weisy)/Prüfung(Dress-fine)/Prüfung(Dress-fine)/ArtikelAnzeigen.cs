﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class ArtikelAnzeigen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
      
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public ArtikelAnzeigen()
        {
            InitializeComponent();
         
        }
      
        private void ArtikelAnzeigen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("Select Artikel_id, Artikelgruppen_id, Artikel_name, Artikel_beschreibung, Artikel_einzelpreis, Artikel_menge, Artikel_verfügbar from Artikel", con);
                ada.Fill(ds, "Artikel");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "Artikel";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
         
        }
       
    }
}
