﻿
namespace Prüfung_Dress_fine_
{
    partial class bestellpositionADD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.tbx_menge = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbx_bestellung = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnbewegungsdaten = new System.Windows.Forms.Button();
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.tbx_apreis = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbx_abeschreibung = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_aname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbx_artikel_id = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbx_endpreis = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panelchildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.tbx_endpreis);
            this.panelchildform.Controls.Add(this.label7);
            this.panelchildform.Controls.Add(this.tbx_apreis);
            this.panelchildform.Controls.Add(this.label1);
            this.panelchildform.Controls.Add(this.tbx_abeschreibung);
            this.panelchildform.Controls.Add(this.label2);
            this.panelchildform.Controls.Add(this.tbx_aname);
            this.panelchildform.Controls.Add(this.label3);
            this.panelchildform.Controls.Add(this.cbx_artikel_id);
            this.panelchildform.Controls.Add(this.label6);
            this.panelchildform.Controls.Add(this.tbx_menge);
            this.panelchildform.Controls.Add(this.label4);
            this.panelchildform.Controls.Add(this.cbx_bestellung);
            this.panelchildform.Controls.Add(this.label5);
            this.panelchildform.Controls.Add(this.btnbewegungsdaten);
            this.panelchildform.Controls.Add(this.dghinzufügen);
            this.panelchildform.Location = new System.Drawing.Point(0, 0);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1215, 767);
            this.panelchildform.TabIndex = 10;
            // 
            // tbx_menge
            // 
            this.tbx_menge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_menge.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_menge.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_menge.Location = new System.Drawing.Point(831, 270);
            this.tbx_menge.Multiline = true;
            this.tbx_menge.Name = "tbx_menge";
            this.tbx_menge.Size = new System.Drawing.Size(190, 34);
            this.tbx_menge.TabIndex = 46;
            this.tbx_menge.TextChanged += new System.EventHandler(this.tbx_menge_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(731, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 24);
            this.label4.TabIndex = 45;
            this.label4.Text = "Menge:";
            // 
            // cbx_bestellung
            // 
            this.cbx_bestellung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_bestellung.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_bestellung.FormattingEnabled = true;
            this.cbx_bestellung.Location = new System.Drawing.Point(266, 280);
            this.cbx_bestellung.Name = "cbx_bestellung";
            this.cbx_bestellung.Size = new System.Drawing.Size(190, 21);
            this.cbx_bestellung.TabIndex = 38;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(31, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 24);
            this.label5.TabIndex = 37;
            this.label5.Text = "Bestellung ID:";
            // 
            // btnbewegungsdaten
            // 
            this.btnbewegungsdaten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbewegungsdaten.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbewegungsdaten.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnbewegungsdaten.Location = new System.Drawing.Point(0, 654);
            this.btnbewegungsdaten.Name = "btnbewegungsdaten";
            this.btnbewegungsdaten.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnbewegungsdaten.Size = new System.Drawing.Size(1216, 113);
            this.btnbewegungsdaten.TabIndex = 34;
            this.btnbewegungsdaten.Text = "Hinzufügen";
            this.btnbewegungsdaten.UseVisualStyleBackColor = true;
            this.btnbewegungsdaten.Click += new System.EventHandler(this.btnbewegungsdaten_Click);
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dghinzufügen.Location = new System.Drawing.Point(0, 2);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersVisible = false;
            this.dghinzufügen.Size = new System.Drawing.Size(1216, 257);
            this.dghinzufügen.TabIndex = 5;
            // 
            // tbx_apreis
            // 
            this.tbx_apreis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_apreis.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_apreis.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_apreis.Location = new System.Drawing.Point(266, 444);
            this.tbx_apreis.Multiline = true;
            this.tbx_apreis.Name = "tbx_apreis";
            this.tbx_apreis.Size = new System.Drawing.Size(190, 34);
            this.tbx_apreis.TabIndex = 54;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(57, 451);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 24);
            this.label1.TabIndex = 53;
            this.label1.Text = "Artikel Preis:";
            // 
            // tbx_abeschreibung
            // 
            this.tbx_abeschreibung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_abeschreibung.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_abeschreibung.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_abeschreibung.Location = new System.Drawing.Point(266, 411);
            this.tbx_abeschreibung.Multiline = true;
            this.tbx_abeschreibung.Name = "tbx_abeschreibung";
            this.tbx_abeschreibung.Size = new System.Drawing.Size(190, 34);
            this.tbx_abeschreibung.TabIndex = 52;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(57, 418);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 24);
            this.label2.TabIndex = 51;
            this.label2.Text = "Artikel Beschreibung:";
            // 
            // tbx_aname
            // 
            this.tbx_aname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_aname.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_aname.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_aname.Location = new System.Drawing.Point(266, 378);
            this.tbx_aname.Multiline = true;
            this.tbx_aname.Name = "tbx_aname";
            this.tbx_aname.Size = new System.Drawing.Size(190, 34);
            this.tbx_aname.TabIndex = 50;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(57, 378);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 24);
            this.label3.TabIndex = 49;
            this.label3.Text = "Artikel Name:";
            // 
            // cbx_artikel_id
            // 
            this.cbx_artikel_id.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_artikel_id.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_artikel_id.FormattingEnabled = true;
            this.cbx_artikel_id.Location = new System.Drawing.Point(266, 357);
            this.cbx_artikel_id.Name = "cbx_artikel_id";
            this.cbx_artikel_id.Size = new System.Drawing.Size(190, 21);
            this.cbx_artikel_id.TabIndex = 48;
            this.cbx_artikel_id.SelectedIndexChanged += new System.EventHandler(this.cbx_artikel_id_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(31, 354);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 24);
            this.label6.TabIndex = 47;
            this.label6.Text = "Artikel_ID:";
            // 
            // tbx_endpreis
            // 
            this.tbx_endpreis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_endpreis.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_endpreis.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_endpreis.Location = new System.Drawing.Point(831, 345);
            this.tbx_endpreis.Multiline = true;
            this.tbx_endpreis.Name = "tbx_endpreis";
            this.tbx_endpreis.Size = new System.Drawing.Size(190, 34);
            this.tbx_endpreis.TabIndex = 56;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(731, 352);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 24);
            this.label7.TabIndex = 55;
            this.label7.Text = "Endpreis:";
            // 
            // bestellpositionADD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1215, 767);
            this.Controls.Add(this.panelchildform);
            this.Name = "bestellpositionADD";
            this.Text = "bestellpositionADD";
            this.Load += new System.EventHandler(this.bestellpositionADD_Load);
            this.panelchildform.ResumeLayout(false);
            this.panelchildform.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.TextBox tbx_menge;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbx_bestellung;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnbewegungsdaten;
        private System.Windows.Forms.DataGridView dghinzufügen;
        private System.Windows.Forms.TextBox tbx_apreis;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbx_abeschreibung;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbx_aname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbx_artikel_id;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbx_endpreis;
        private System.Windows.Forms.Label label7;
    }
}