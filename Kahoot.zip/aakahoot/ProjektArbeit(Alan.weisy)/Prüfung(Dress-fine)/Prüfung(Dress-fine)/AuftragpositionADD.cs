﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class AuftragpositionADD : Form
    {
        private String Connectionstring = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public AuftragpositionADD()
        {
            InitializeComponent();
        }

        private void tbx_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void AuftragpositionADD_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Artikel ORDER BY Artikel_id ASC", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_artikel_id.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("SELECT * FROM Auftrag ORDER BY Auftrag_id ASC", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbx_auftrag_id.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim combobox zu füllen");
            }
            con.Close();
            datagridviewfüllen();
            rechnung();
        }
        private void datagridviewfüllen()
        {
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("Select * from Auftragposition", con);
                ada.Fill(ds, "Auftrag");
                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Auftrag";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
        }

        private void cbx_auftrag_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_auftrag_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Auftrag where Auftrag_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_auftrag.Text = dr.GetString(3);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Auftrag" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cbx_artikel_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_artikel_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Artikel where Artikel_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_aname.Text = dr.GetString(2);
                tbx_abeschreibung.Text = dr.GetString(3);
                tbx_apreis.Text = dr.GetInt32(4).ToString();
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Artikegruppen" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        private void rechnung()
        {
            try
            {
                //überprüfen ob menge und preis gültige zahlen sind
                if (double.TryParse(tbx_menge.Text, out double menge)&& double.TryParse(tbx_apreis.Text, out double preis))
                {
                    double gesamtkosten = menge * preis;
                    tbx_gesamtplreis.Text = gesamtkosten.ToString();
                }
            }
            catch (Exception a)
            {

                throw;
            }
        }

        private void tbx_menge_TextChanged(object sender, EventArgs e)
        {
            rechnung();
        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(Connectionstring))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_artikel_id.Text) || string.IsNullOrWhiteSpace(cbx_auftrag_id.Text) || string.IsNullOrWhiteSpace(tbx_menge.Text)
                        )
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        using (OleDbCommand insert = new OleDbCommand("INSERT INTO Auftragposition ( Auftrag_id, Artikel_id, Menge)"
                            + "VALUES(@afg, @ark, @menge)", con))
                        {
                            insert.Parameters.AddWithValue("@afg", Convert.ToInt32(cbx_auftrag_id.Text));
                            insert.Parameters.AddWithValue("@ark", Convert.ToInt32(cbx_artikel_id.Text));
                            insert.Parameters.AddWithValue("@menge", Convert.ToInt32(tbx_menge.Text));

                            insert.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Gespeichert!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        datagridviewfüllen();
                    }
                }
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim speichern" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
