﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class ArtikelEntfernen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        string mnr = "";
        bool clicked;
        public ArtikelEntfernen()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void ArtikelEntfernen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
                ada = new OleDbDataAdapter();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            datagridviewfüllen();
        }
        private void datagridviewfüllen()
        {
            try
            {
                ds.Clear();
                ada.SelectCommand = new OleDbCommand("SELECT Artikel_id, Artikelgruppen_id, Artikel_name, Artikel_beschreibung, Artikel_einzelpreis, Artikel_menge, Artikel_verfügbar FROM Artikel WHERE Artikel_gelöscht = false", con);
                ada.Fill(ds, "Artikel");

                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Artikel";
              
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei datagridview:" + a);
            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (clicked == true)
            {
                con.Open();
                cmd = new OleDbCommand("UPDATE Artikel SET Artikel_gelöscht = true WHERE Artikel_id =" + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Artikel");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Artikel";
                con.Close();
            }
            else
            {
                MessageBox.Show("Sie müssen dopplt auf den gewünschten Artikel_id Klicken damit sie ihn Löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openchildform(new EntfernenArtikel());
            ds.Clear();
            ada.Fill(ds, "Artikel");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Artikel";
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            clicked = true;
            if (e.RowIndex >= 0)
            {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Artikel_id"].FormattedValue.ToString();
                label2.Text = dgentfernen.Rows[e.RowIndex].Cells["Artikel_id"].FormattedValue.ToString();
            }
        }
    }
}
