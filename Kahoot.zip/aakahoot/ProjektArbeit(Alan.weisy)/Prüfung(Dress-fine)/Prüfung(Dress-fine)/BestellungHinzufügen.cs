﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class BestellungHinzufügen : Form
    {
        private String Connectionstring = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public BestellungHinzufügen()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void BestellungHinzufügen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Status ORDER BY Status_id ASC", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_status_id.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("SELECT * FROM Franchise ORDER BY Franchise_id ASC", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbx_franchise.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim combobox zu füllen");
            }
            con.Close();
            datagridviewfüllen();
        }
        private void datagridviewfüllen()
        {
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("Select Bestellung_id, Franchise_id, Status_id, Datum from Bestellung", con);
                ada.Fill(ds, "Bestellung");
                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Bestellung";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(Connectionstring))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_status_id.Text) || string.IsNullOrWhiteSpace(cbx_franchise.Text) || string.IsNullOrWhiteSpace(tbx_datum.Text)
                        )
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        using (OleDbCommand insert = new OleDbCommand("INSERT INTO Bestellung (Status_id, Franchise_id, Datum)"
                            + "VALUES(@Status, @fra, @Datume)", con))
                        {
                            insert.Parameters.AddWithValue("@Status", Convert.ToInt32(cbx_status_id.Text));
                            insert.Parameters.AddWithValue("@fra", Convert.ToInt32(cbx_franchise.Text));
                            insert.Parameters.AddWithValue("@Datume", tbx_datum.Text);

                            insert.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Gespeichert!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        datagridviewfüllen();
                        openchildform(new bestellpositionADD());
                    }
                }
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim speichern" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cbx_status_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_status_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Status where Status_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_status.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Status" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cbx_franchise_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_franchise.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Franchise where franchise_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_name.Text = dr.GetString(2);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Artikegruppen" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
