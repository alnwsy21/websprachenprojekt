﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class BearbeitenAuftrag : Form
    {
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdateRow { get; private set; }
        public BearbeitenAuftrag(DataGridViewRow selectedRow, string connectionString)
        {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void BearbeitenAuftrag_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Dress.accdb";
                AnzeigenDerDaten();
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Status ORDER BY Status_id ASC", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_status_id.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("SELECT * FROM Lieferanten ORDER BY Lieferant_id ASC", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbx_lieferanten_id.Items.Add(dr.GetInt32(0));
                }
                con.Close();
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim combobox zu füllen");
            }
        }
        private void AnzeigenDerDaten()
        {
            try
            {
                cbx_status_id.Text = selectedRow.Cells["Status_id"].Value.ToString();
                cbx_lieferanten_id.Text = selectedRow.Cells["Lieferant_id"].Value.ToString();
                tbx_datum.Text = selectedRow.Cells["Datum"].Value.ToString();

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim anzeigen der daten!" + a, "Infrmation Fehler", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {
           

            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_lieferanten_id.Text) || string.IsNullOrWhiteSpace(cbx_status_id.Text) || string.IsNullOrWhiteSpace(tbx_datum.Text)
                     )
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string query = "UPDATE Auftrag SET Status_id = ?, Lieferant_id = ?, Datum = ? WHERE Auftrag_id = ?";
                        using (OleDbCommand Insertcmd = new OleDbCommand(query, con))
                        {
                            Insertcmd.Parameters.AddWithValue("@Status_id", Convert.ToInt32(cbx_status_id.Text));
                            Insertcmd.Parameters.AddWithValue("@Lieferant_id", Convert.ToInt32(cbx_lieferanten_id.Text));
                            Insertcmd.Parameters.AddWithValue("@Datum", tbx_datum.Text);

                            Insertcmd.Parameters.AddWithValue("@Auftrag_id", selectedRow.Cells["Auftrag_id"].Value);
                            Insertcmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Bearbeitet!");
                        UpdateRow = selectedRow;
                    }
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler Beim Bearbeiten!" + a, "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbx_status_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_status_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Status where Status_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_status.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Status" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cbx_lieferanten_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_lieferanten_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Lieferanten where Lieferant_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_name.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Artikegruppen" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
