﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class EntfernenAuftrag : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        string mnr = "";
        bool clicked;
        public EntfernenAuftrag()
        {
            InitializeComponent();
        }

        private void EntfernenAuftrag_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("SELECT * FROM Auftrag WHERE Auftrag_gelöscht = true", con);
                ada.Fill(ds, "Auftrag");

                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Auftrag";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei datagridview:" + a);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgentfernen.SelectedRows.Count > 0)
                {
                    con.Open();
                    cmd = new OleDbCommand("UPDATE Auftrag SET Auftrag_gelöscht = false WHERE Auftrag_id =" + mnr, con);
                    cmd.ExecuteNonQuery();
                    ds.Clear();
                    ada.Fill(ds, "Lager");
                    dgentfernen.DataSource = ds;
                    dgentfernen.DataMember = "Lager";
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Bitte Wählen sie eine datensatz aus, um ihn zu aktualisieren");
                }
            }
            catch (Exception a)
            {

                MessageBox.Show("Derdatensatz konnte nicht hinzugefügr werden" + a);
            }
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            clicked = true;
            if (e.RowIndex >= 0)
            {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Auftrag_id"].FormattedValue.ToString();
                label2.Text = dgentfernen.Rows[e.RowIndex].Cells["Auftrag_id"].FormattedValue.ToString();
            }
        }
    }
}
