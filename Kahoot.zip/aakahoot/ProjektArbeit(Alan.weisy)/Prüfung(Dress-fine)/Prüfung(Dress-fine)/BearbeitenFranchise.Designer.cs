﻿
namespace Prüfung_Dress_fine_
{
    partial class BearbeitenFranchise
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tbx_fnehmername = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbx_email = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbx_tele = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbx_adresse = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_fname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbx_fnehmer = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(0, 461);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(1018, 203);
            this.button1.TabIndex = 29;
            this.button1.Text = "Speichern";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbx_fnehmername
            // 
            this.tbx_fnehmername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_fnehmername.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_fnehmername.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_fnehmername.Location = new System.Drawing.Point(326, 109);
            this.tbx_fnehmername.Multiline = true;
            this.tbx_fnehmername.Name = "tbx_fnehmername";
            this.tbx_fnehmername.Size = new System.Drawing.Size(204, 37);
            this.tbx_fnehmername.TabIndex = 41;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(88, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(221, 24);
            this.label6.TabIndex = 40;
            this.label6.Text = "Franchisenehmer Name:";
            // 
            // tbx_email
            // 
            this.tbx_email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_email.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_email.Location = new System.Drawing.Point(748, 180);
            this.tbx_email.Multiline = true;
            this.tbx_email.Name = "tbx_email";
            this.tbx_email.Size = new System.Drawing.Size(204, 37);
            this.tbx_email.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(540, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 24);
            this.label5.TabIndex = 38;
            this.label5.Text = "E-Mail:";
            // 
            // tbx_tele
            // 
            this.tbx_tele.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_tele.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_tele.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_tele.Location = new System.Drawing.Point(748, 87);
            this.tbx_tele.Multiline = true;
            this.tbx_tele.Name = "tbx_tele";
            this.tbx_tele.Size = new System.Drawing.Size(204, 37);
            this.tbx_tele.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(540, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 24);
            this.label4.TabIndex = 36;
            this.label4.Text = "Telefon:";
            // 
            // tbx_adresse
            // 
            this.tbx_adresse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_adresse.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_adresse.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_adresse.Location = new System.Drawing.Point(326, 254);
            this.tbx_adresse.Multiline = true;
            this.tbx_adresse.Name = "tbx_adresse";
            this.tbx_adresse.Size = new System.Drawing.Size(204, 37);
            this.tbx_adresse.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(65, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 24);
            this.label3.TabIndex = 34;
            this.label3.Text = "Adresse:";
            // 
            // tbx_fname
            // 
            this.tbx_fname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_fname.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_fname.Location = new System.Drawing.Point(326, 180);
            this.tbx_fname.Multiline = true;
            this.tbx_fname.Name = "tbx_fname";
            this.tbx_fname.Size = new System.Drawing.Size(204, 37);
            this.tbx_fname.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(55, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 24);
            this.label2.TabIndex = 32;
            this.label2.Text = "Franchise Name:";
            // 
            // cbx_fnehmer
            // 
            this.cbx_fnehmer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_fnehmer.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_fnehmer.FormattingEnabled = true;
            this.cbx_fnehmer.Location = new System.Drawing.Point(326, 90);
            this.cbx_fnehmer.Name = "cbx_fnehmer";
            this.cbx_fnehmer.Size = new System.Drawing.Size(204, 21);
            this.cbx_fnehmer.TabIndex = 31;
            this.cbx_fnehmer.SelectedIndexChanged += new System.EventHandler(this.cbx_fnehmer_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(55, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 24);
            this.label1.TabIndex = 30;
            this.label1.Text = "Franchisenehmer_id";
            // 
            // BearbeitenFranchise
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1018, 664);
            this.Controls.Add(this.tbx_fnehmername);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbx_email);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbx_tele);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbx_adresse);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbx_fname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbx_fnehmer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "BearbeitenFranchise";
            this.Text = "BearbeitenFranchise";
            this.Load += new System.EventHandler(this.BearbeitenFranchise_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbx_fnehmername;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbx_email;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbx_tele;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbx_adresse;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbx_fname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbx_fnehmer;
        private System.Windows.Forms.Label label1;
    }
}