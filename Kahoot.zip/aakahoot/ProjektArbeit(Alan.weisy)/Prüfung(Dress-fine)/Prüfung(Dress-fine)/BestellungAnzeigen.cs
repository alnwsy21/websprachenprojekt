﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class BestellungAnzeigen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public BestellungAnzeigen()
        {
            InitializeComponent();
        }

        private void BestellungAnzeigen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("Select Bestellung_id, Franchise_id, Status_id, Datum from Bestellung", con);
                ada.Fill(ds, "Bestellung");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "Bestellung";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
        }
    }
}
