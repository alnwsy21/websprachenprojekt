﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class BearbeitenFranchise : Form
    {
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdateRow { get; private set; }
        public BearbeitenFranchise(DataGridViewRow selectedRow, string connectionString)
        {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void BearbeitenFranchise_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Dress.accdb";
                AnzeigenDerDaten();
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Franchisenehmer ORDER BY Franchisenehmer_id ASC", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_fnehmer.Items.Add(dr.GetInt32(0));
                }
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler beim anzeigen der daten!" + a, "Infrmation Fehler", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }

        }
        private void AnzeigenDerDaten()
        {
            try
            {
                cbx_fnehmer.Text = selectedRow.Cells[1].Value.ToString();
                tbx_fname.Text = selectedRow.Cells[2].Value.ToString();
                tbx_adresse.Text = selectedRow.Cells[3].Value.ToString();
                tbx_tele.Text = selectedRow.Cells[4].Value.ToString();
                tbx_email.Text = selectedRow.Cells[5].Value.ToString();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler beim anzeigen der daten!" + a, "Infrmation Fehler", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void cbx_fnehmer_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_fnehmer.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Franchisenehmer where Franchisenehmer_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_fnehmername.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Franchisenehmer" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_fnehmer.Text) || string.IsNullOrWhiteSpace(tbx_adresse.Text)
                        || string.IsNullOrWhiteSpace(tbx_fname.Text) || string.IsNullOrWhiteSpace(tbx_email.Text)
                        || string.IsNullOrWhiteSpace(tbx_tele.Text))
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string query = "UPDATE Franchise SET Franchisenehmer_id = ?, F_name = ?, Adresse = ?, Telefon = ?, Email = ? WHERE Franchise_id = ?";
                        using (OleDbCommand Insertcmd = new OleDbCommand(query, con))
                        {
                            Insertcmd.Parameters.AddWithValue("@Franchisenehmer_id", Convert.ToInt32(cbx_fnehmer.Text));
                            Insertcmd.Parameters.AddWithValue("@F_name", tbx_fname  .Text);
                            Insertcmd.Parameters.AddWithValue("@Adresse", tbx_adresse.Text);
                            Insertcmd.Parameters.AddWithValue("@Telefon", Convert.ToInt32(tbx_tele.Text));
                            Insertcmd.Parameters.AddWithValue("@Email", tbx_email.Text);
                            Insertcmd.Parameters.AddWithValue("@Franchise_id", selectedRow.Cells["Franchise_id"].Value);
                            Insertcmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Bearbeitet!", "Erfolg Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        UpdateRow = selectedRow;
                    }
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler Beim Bearbeiten!" + a, "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
