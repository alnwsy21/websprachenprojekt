﻿
namespace Prüfung_Dress_fine_
{
    partial class FranchiseHinzufügen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.panelchildform.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.label1);
            this.panelchildform.Controls.Add(this.panel1);
            this.panelchildform.Location = new System.Drawing.Point(-3, -1);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1023, 664);
            this.panelchildform.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(178, 483);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(657, 73);
            this.label1.TabIndex = 5;
            this.label1.Text = "Franchise Hinzufügen";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dghinzufügen);
            this.panel1.Location = new System.Drawing.Point(-3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1018, 213);
            this.panel1.TabIndex = 0;
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.Location = new System.Drawing.Point(0, 0);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersVisible = false;
            this.dghinzufügen.Size = new System.Drawing.Size(1015, 213);
            this.dghinzufügen.TabIndex = 0;
            this.dghinzufügen.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dghinzufügen_CellDoubleClick);
            // 
            // FranchiseHinzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 660);
            this.Controls.Add(this.panelchildform);
            this.Name = "FranchiseHinzufügen";
            this.Text = "FranchiseHinzufügen";
            this.Load += new System.EventHandler(this.FranchiseHinzufügen_Load);
            this.panelchildform.ResumeLayout(false);
            this.panelchildform.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dghinzufügen;
        private System.Windows.Forms.Label label1;
    }
}