﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class BestellungEntfernen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        string mnr = "";
        bool clicked;
        public BestellungEntfernen()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void BestellungEntfernen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
                ada = new OleDbDataAdapter();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            datagridviewfüllen();
        }
        private void datagridviewfüllen()
        {
            try
            {
                ds.Clear();
                ada.SelectCommand = new OleDbCommand("Select Bestellung_id, Franchise_id, Status_id, Datum from Bestellung WHERE Bestellung_gelöscht = false", con);
                ada.Fill(ds, "Auftrag");

                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Auftrag";

            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei datagridview:" + a);
            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (clicked == true)
            {
                con.Open();
                cmd = new OleDbCommand("UPDATE Bestellung SET Bestellung_gelöscht = true WHERE Bestellung_id =" + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Bestellung");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Bestellung";
                con.Close();
            }
            else
            {
                MessageBox.Show("Sie müssen dopplt auf den gewünschten Auftrag_id Klicken damit sie ihn Löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openchildform(new EntfernenBestellung());
            ds.Clear();
            ada.Fill(ds, "Bestellung");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Bestellung";
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            clicked = true;
            if (e.RowIndex >= 0)
            {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Bestellung_id"].FormattedValue.ToString();
                label2.Text = dgentfernen.Rows[e.RowIndex].Cells["Bestellung_id"].FormattedValue.ToString();
            }
        }
    }
}
