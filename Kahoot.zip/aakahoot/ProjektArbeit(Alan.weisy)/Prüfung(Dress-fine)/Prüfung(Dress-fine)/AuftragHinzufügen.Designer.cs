﻿
namespace Prüfung_Dress_fine_
{
    partial class AuftragHinzufügen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnbewegungsdaten = new System.Windows.Forms.Button();
            this.tbx_datum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbx_name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbx_lieferanten_id = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_status = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbx_status_id = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.panelchildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.button1);
            this.panelchildform.Controls.Add(this.btnbewegungsdaten);
            this.panelchildform.Controls.Add(this.tbx_datum);
            this.panelchildform.Controls.Add(this.label4);
            this.panelchildform.Controls.Add(this.tbx_name);
            this.panelchildform.Controls.Add(this.label1);
            this.panelchildform.Controls.Add(this.cbx_lieferanten_id);
            this.panelchildform.Controls.Add(this.label3);
            this.panelchildform.Controls.Add(this.tbx_status);
            this.panelchildform.Controls.Add(this.label6);
            this.panelchildform.Controls.Add(this.cbx_status_id);
            this.panelchildform.Controls.Add(this.label5);
            this.panelchildform.Controls.Add(this.dghinzufügen);
            this.panelchildform.Controls.Add(this.label2);
            this.panelchildform.Location = new System.Drawing.Point(-2, -1);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1216, 758);
            this.panelchildform.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(870, 645);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(346, 113);
            this.button1.TabIndex = 34;
            this.button1.Text = "Zur Auftragsposition";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnbewegungsdaten
            // 
            this.btnbewegungsdaten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbewegungsdaten.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbewegungsdaten.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnbewegungsdaten.Location = new System.Drawing.Point(3, 645);
            this.btnbewegungsdaten.Name = "btnbewegungsdaten";
            this.btnbewegungsdaten.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnbewegungsdaten.Size = new System.Drawing.Size(346, 113);
            this.btnbewegungsdaten.TabIndex = 33;
            this.btnbewegungsdaten.Text = "Hinzufügen";
            this.btnbewegungsdaten.UseVisualStyleBackColor = true;
            this.btnbewegungsdaten.Click += new System.EventHandler(this.btnbewegungsdaten_Click);
            // 
            // tbx_datum
            // 
            this.tbx_datum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_datum.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_datum.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_datum.Location = new System.Drawing.Point(915, 362);
            this.tbx_datum.Multiline = true;
            this.tbx_datum.Name = "tbx_datum";
            this.tbx_datum.Size = new System.Drawing.Size(190, 34);
            this.tbx_datum.TabIndex = 32;
            this.tbx_datum.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(840, 362);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 24);
            this.label4.TabIndex = 31;
            this.label4.Text = "Datum:";
            // 
            // tbx_name
            // 
            this.tbx_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_name.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_name.Location = new System.Drawing.Point(621, 386);
            this.tbx_name.Multiline = true;
            this.tbx_name.Name = "tbx_name";
            this.tbx_name.Size = new System.Drawing.Size(190, 34);
            this.tbx_name.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(509, 386);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 24);
            this.label1.TabIndex = 29;
            this.label1.Text = "Name:";
            // 
            // cbx_lieferanten_id
            // 
            this.cbx_lieferanten_id.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_lieferanten_id.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_lieferanten_id.FormattingEnabled = true;
            this.cbx_lieferanten_id.Location = new System.Drawing.Point(621, 365);
            this.cbx_lieferanten_id.Name = "cbx_lieferanten_id";
            this.cbx_lieferanten_id.Size = new System.Drawing.Size(190, 21);
            this.cbx_lieferanten_id.TabIndex = 28;
            this.cbx_lieferanten_id.SelectedIndexChanged += new System.EventHandler(this.cbx_lieferanten_id_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(445, 362);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 24);
            this.label3.TabIndex = 27;
            this.label3.Text = "Lieferanten ID:";
            // 
            // tbx_status
            // 
            this.tbx_status.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_status.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_status.Location = new System.Drawing.Point(214, 387);
            this.tbx_status.Multiline = true;
            this.tbx_status.Name = "tbx_status";
            this.tbx_status.Size = new System.Drawing.Size(190, 34);
            this.tbx_status.TabIndex = 26;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(81, 388);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 24);
            this.label6.TabIndex = 25;
            this.label6.Text = "Bezeichnung:";
            // 
            // cbx_status_id
            // 
            this.cbx_status_id.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_status_id.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_status_id.FormattingEnabled = true;
            this.cbx_status_id.Location = new System.Drawing.Point(214, 367);
            this.cbx_status_id.Name = "cbx_status_id";
            this.cbx_status_id.Size = new System.Drawing.Size(190, 21);
            this.cbx_status_id.TabIndex = 24;
            this.cbx_status_id.SelectedIndexChanged += new System.EventHandler(this.cbx_status_id_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(55, 362);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 24);
            this.label5.TabIndex = 23;
            this.label5.Text = "Status ID:";
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dghinzufügen.Location = new System.Drawing.Point(0, 1);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersVisible = false;
            this.dghinzufügen.Size = new System.Drawing.Size(1216, 321);
            this.dghinzufügen.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(401, 668);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(436, 55);
            this.label2.TabIndex = 3;
            this.label2.Text = "Auftrag Hinzufügen";
            // 
            // AuftragHinzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 757);
            this.Controls.Add(this.panelchildform);
            this.Name = "AuftragHinzufügen";
            this.Text = "AuftragHinzufügen";
            this.Load += new System.EventHandler(this.AuftragHinzufügen_Load);
            this.panelchildform.ResumeLayout(false);
            this.panelchildform.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.DataGridView dghinzufügen;
        private System.Windows.Forms.TextBox tbx_datum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbx_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbx_lieferanten_id;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbx_status;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbx_status_id;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnbewegungsdaten;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
    }
}