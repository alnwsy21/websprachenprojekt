﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class LagerAnzeigen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public LagerAnzeigen()
        {
            InitializeComponent();
        }

        private void LagerAnzeigen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("SELECT Ort, Kapazität FROM Lager", con);
                ada.Fill(ds, "Lager");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "Lager";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
        }

    }
}
