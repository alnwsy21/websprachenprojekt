﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class LagerHinzufügen : Form
    {
        private String Connectionstring = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public LagerHinzufügen()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void LagerHinzufügen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            populatedatagridview();
                
             }
        private void populatedatagridview()
        {
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("SELECT Ort, Kapazität FROM Lager ORDER BY Lager_id ASC", con);
                ada.Fill(ds, "Lager");
                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Lager";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(Connectionstring))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(tbx_ort.Text) || string.IsNullOrWhiteSpace(tbx_kap.Text)
                        )
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        using (OleDbCommand insert = new OleDbCommand("INSERT INTO Lager (Ort, Kapazität)"
                            + "VALUES(@Ort, @Kap)", con))
                        {
                            insert.Parameters.AddWithValue("@Ort", tbx_ort.Text);
                            insert.Parameters.AddWithValue("@Kap", Convert.ToInt32(tbx_kap.Text));
                          
                            insert.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Gespeichert!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        populatedatagridview();
                    }
                }
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim speichern" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
