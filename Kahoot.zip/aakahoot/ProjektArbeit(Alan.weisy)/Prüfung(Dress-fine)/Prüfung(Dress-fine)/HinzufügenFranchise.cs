﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class HinzufügenFranchise : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string Connectionstring = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public HinzufügenFranchise()
        {
            InitializeComponent();
        }

        private void HinzufügenFranchise_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Franchisenehmer ORDER BY Franchisenehmer_id ASC", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_fnehmer.Items.Add(dr.GetInt32(0));
                }
                con.Close();
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim combobox zu füllen");
            }
        }

        private void cbx_fnehmer_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_fnehmer.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Franchisenehmer where Franchisenehmer_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_fnehmername.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Artikegruppen" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(Connectionstring))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_fnehmer.Text) || string.IsNullOrWhiteSpace(tbx_adresse.Text)
                        || string.IsNullOrWhiteSpace(tbx_email.Text) || string.IsNullOrWhiteSpace(tbx_fname.Text) || string.IsNullOrWhiteSpace(tbx_tele.Text))
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        using (OleDbCommand insert = new OleDbCommand("INSERT INTO Franchise (Franchisenehmer_id, F_name, Adresse, Telefon, Email)"
                            + "VALUES(@fran, @name, @adresse, @tle, @ema)", con))
                        {
                            insert.Parameters.AddWithValue("@fran", Convert.ToInt32(cbx_fnehmer.Text));
                            insert.Parameters.AddWithValue("@name", tbx_fname.Text);
                            insert.Parameters.AddWithValue("@adresse", tbx_adresse.Text);
                            insert.Parameters.AddWithValue("@tle", Convert.ToInt32(tbx_tele.Text));
                            insert.Parameters.AddWithValue("@ema", tbx_email.Text);
                            insert.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Gespeichert!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim speichern" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
