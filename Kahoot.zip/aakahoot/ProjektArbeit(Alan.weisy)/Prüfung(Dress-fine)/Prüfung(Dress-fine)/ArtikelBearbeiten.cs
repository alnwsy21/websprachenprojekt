﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class ArtikelBearbeiten : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Dress.accdb";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public ArtikelBearbeiten()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void ArtikelBearbeiten_Load(object sender, EventArgs e)
        {

            try
            {
                con.ConnectionString = connectionString;
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            LoadData();
        }
        private void LoadData()
        {
            try
            {
                ds.Clear();
                using(OleDbDataAdapter ada = new OleDbDataAdapter("Select Artikel_id, Artikelgruppen_id, Artikel_name, Artikel_beschreibung, Artikel_einzelpreis, Artikel_menge, Artikel_verfügbar from Artikel", con))
                {
                    ada.Fill(ds, "Artikel");
                }
                dgbearbeiten.DataSource = ds;
                dgbearbeiten.DataMember = "Artikel";
                dgbearbeiten.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            }
            catch (Exception a)
            {

                MessageBox.Show("fehler bei datagridview anzeige");
            }
            finally
            {
                con.Close();
            }
        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedrow = dgbearbeiten.Rows[e.RowIndex];
                BearbeitenArtikel bearbeiten = new BearbeitenArtikel(selectedrow, connectionString);
                openchildform(bearbeiten);
            }
        }

        private void panelchildform_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
