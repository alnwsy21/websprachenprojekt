﻿
namespace Prüfung_Dress_fine_
{
    partial class LagerHinzufügen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.btnbewegungsdaten = new System.Windows.Forms.Button();
            this.tbx_kap = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbx_ort = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.panelchildform.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.btnbewegungsdaten);
            this.panelchildform.Controls.Add(this.tbx_kap);
            this.panelchildform.Controls.Add(this.label6);
            this.panelchildform.Controls.Add(this.tbx_ort);
            this.panelchildform.Controls.Add(this.label5);
            this.panelchildform.Controls.Add(this.panel1);
            this.panelchildform.Location = new System.Drawing.Point(-5, 0);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1043, 700);
            this.panelchildform.TabIndex = 1;
            // 
            // btnbewegungsdaten
            // 
            this.btnbewegungsdaten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbewegungsdaten.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbewegungsdaten.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnbewegungsdaten.Location = new System.Drawing.Point(3, 484);
            this.btnbewegungsdaten.Name = "btnbewegungsdaten";
            this.btnbewegungsdaten.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnbewegungsdaten.Size = new System.Drawing.Size(1037, 215);
            this.btnbewegungsdaten.TabIndex = 21;
            this.btnbewegungsdaten.Text = "Speichern";
            this.btnbewegungsdaten.UseVisualStyleBackColor = true;
            this.btnbewegungsdaten.Click += new System.EventHandler(this.btnbewegungsdaten_Click);
            // 
            // tbx_kap
            // 
            this.tbx_kap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_kap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_kap.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_kap.Location = new System.Drawing.Point(512, 337);
            this.tbx_kap.Multiline = true;
            this.tbx_kap.Name = "tbx_kap";
            this.tbx_kap.Size = new System.Drawing.Size(182, 35);
            this.tbx_kap.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(312, 341);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 24);
            this.label6.TabIndex = 19;
            this.label6.Text = "Lager Kapazität:";
            // 
            // tbx_ort
            // 
            this.tbx_ort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_ort.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_ort.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_ort.Location = new System.Drawing.Point(512, 269);
            this.tbx_ort.Multiline = true;
            this.tbx_ort.Name = "tbx_ort";
            this.tbx_ort.Size = new System.Drawing.Size(182, 35);
            this.tbx_ort.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(312, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 24);
            this.label5.TabIndex = 17;
            this.label5.Text = "Lager Ort:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dghinzufügen);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1037, 213);
            this.panel1.TabIndex = 0;
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.Location = new System.Drawing.Point(3, 0);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersVisible = false;
            this.dghinzufügen.Size = new System.Drawing.Size(1031, 213);
            this.dghinzufügen.TabIndex = 0;
            // 
            // LagerHinzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 700);
            this.Controls.Add(this.panelchildform);
            this.Name = "LagerHinzufügen";
            this.Text = "LagerHinzufügen";
            this.Load += new System.EventHandler(this.LagerHinzufügen_Load);
            this.panelchildform.ResumeLayout(false);
            this.panelchildform.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dghinzufügen;
        private System.Windows.Forms.Button btnbewegungsdaten;
        private System.Windows.Forms.TextBox tbx_kap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbx_ort;
        private System.Windows.Forms.Label label5;
    }
}