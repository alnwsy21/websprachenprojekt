﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prüfung_Dress_fine_
{
    public partial class BestellungVerwaltung : Form
    {
        public BestellungVerwaltung()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void BestellungVerwaltung_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            openchildform(new BestellungAnzeigen());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openchildform(new BestellungHinzufügen());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openchildform(new BestellungBearbeiten());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            openchildform(new BestellungEntfernen());
        }
    }
}
