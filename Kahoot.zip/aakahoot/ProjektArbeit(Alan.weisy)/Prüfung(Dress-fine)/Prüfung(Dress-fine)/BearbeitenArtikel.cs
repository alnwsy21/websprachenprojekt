﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class BearbeitenArtikel : Form
    {
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdateRow { get; private set; }
        public BearbeitenArtikel(DataGridViewRow selectedRow, string connectionString)
        {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void BearbeitenArtikel_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Dress.accdb";
                AnzeigenDerDaten();
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Artikelgruppen ORDER BY Artikelgruppen_id ASC", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_a_gruppen_id.Items.Add(dr.GetInt32(0));
                }
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler beim anzeigen der daten!" + a, "Infrmation Fehler", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
           
        }
        private void AnzeigenDerDaten()
        {
            try
            {
                cbx_a_gruppen_id.Text = selectedRow.Cells[1].Value.ToString();
                tbx_Aname.Text = selectedRow.Cells[2].Value.ToString();
                tbx_beschreibung.Text = selectedRow.Cells[3].Value.ToString();
                tbx_preis.Text = selectedRow.Cells[4].Value.ToString();
                tbx_menge.Text = selectedRow.Cells[5].Value.ToString();
                tbx_verfügbar.Text = selectedRow.Cells[6].Value.ToString();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler beim anzeigen der daten!" + a, "Infrmation Fehler", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void cbx_a_gruppen_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_a_gruppen_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Artikelgruppen where Artikelgruppen_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_agname.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Artikegruppen" + a , "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {


            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_a_gruppen_id.Text) || string.IsNullOrWhiteSpace(tbx_Aname.Text)
                        || string.IsNullOrWhiteSpace(tbx_beschreibung.Text) || string.IsNullOrWhiteSpace(tbx_menge.Text)
                        || string.IsNullOrWhiteSpace(tbx_preis.Text) || string.IsNullOrWhiteSpace(tbx_verfügbar.Text))
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string query = "UPDATE Artikel SET Artikelgruppen_id = ?, Artikel_name = ?, Artikel_beschreibung = ?, Artikel_einzelpreis = ?, Artikel_menge = ?, Artikel_verfügbar = ? WHERE Artikel_id = ?";
                        using(OleDbCommand Insertcmd = new OleDbCommand(query, con))
                        {
                            Insertcmd.Parameters.AddWithValue("@Artikelgruppen_id", Convert.ToInt32(cbx_a_gruppen_id.Text));
                            Insertcmd.Parameters.AddWithValue("@Artikel_name", tbx_Aname.Text);
                            Insertcmd.Parameters.AddWithValue("@Artikel_beschreibung", tbx_beschreibung.Text);
                            Insertcmd.Parameters.AddWithValue("@Artikel_einzelpreis", Convert.ToInt32(tbx_preis.Text));
                            Insertcmd.Parameters.AddWithValue("@Artikel_menge", Convert.ToInt32(tbx_menge.Text));
                            Insertcmd.Parameters.AddWithValue("@Artikel_verfügbar", tbx_verfügbar.Text);
                            Insertcmd.Parameters.AddWithValue("@Artikel_id", selectedRow.Cells["Artikel_id"].Value);
                            Insertcmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Bearbeitet!");
                        UpdateRow = selectedRow;
                    }
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler Beim Bearbeiten!" + a, "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }




          
     
        }
    }
}
