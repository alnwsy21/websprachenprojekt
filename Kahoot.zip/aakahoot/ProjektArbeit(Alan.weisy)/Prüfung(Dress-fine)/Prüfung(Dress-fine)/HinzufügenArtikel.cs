﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class HinzufügenArtikel : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string Connectionstring = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public HinzufügenArtikel()
        {
            InitializeComponent();
        }

        private void HinzufügenArtikel_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Artikelgruppen ORDER BY Artikelgruppen_id ASC", con);
               dr =  cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_aGruppen_id.Items.Add(dr.GetInt32(0));
                }
                con.Close();
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim combobox zu füllen");
            }
        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {
            try
            {
                using(OleDbConnection con = new OleDbConnection(Connectionstring))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_aGruppen_id.Text) || string.IsNullOrWhiteSpace(tbx_Aname.Text) 
                        || string.IsNullOrWhiteSpace(tbx_beschreibung.Text) || string.IsNullOrWhiteSpace(tbx_menge.Text) || string.IsNullOrWhiteSpace(tbx_preis.Text) || string.IsNullOrWhiteSpace(tbx_verfügbar.Text))
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        using (OleDbCommand insert = new OleDbCommand("INSERT INTO Artikel (Artikelgruppen_id, Artikel_name, Artikel_beschreibung, Artikel_einzelpreis, Artikel_menge, Artikel_verfügbar)"
                            + "VALUES(@gruppe, @name, @beschreibung, @preis, @menge, @verfügbar)", con))
                        {
                            insert.Parameters.AddWithValue("@gruppe", Convert.ToInt32(cbx_aGruppen_id.Text));
                            insert.Parameters.AddWithValue("@name", tbx_Aname.Text);
                            insert.Parameters.AddWithValue("@beschreibung", tbx_beschreibung.Text);
                            insert.Parameters.AddWithValue("@preis", Convert.ToInt32(tbx_preis.Text));
                            insert.Parameters.AddWithValue("@menge", Convert.ToInt32(tbx_menge.Text));
                            insert.Parameters.AddWithValue("@verfügbar", tbx_verfügbar.Text);
                            insert.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Gespeichert!","Information",  MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
            catch (Exception a )
            {

                MessageBox.Show("fehler beim speichern" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cbx_aGruppen_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_aGruppen_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Artikelgruppen where Artikelgruppen_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_agname.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Artikegruppen" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
