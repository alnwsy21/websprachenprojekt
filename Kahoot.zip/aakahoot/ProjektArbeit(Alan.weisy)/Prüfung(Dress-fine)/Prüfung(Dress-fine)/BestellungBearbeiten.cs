﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class BestellungBearbeiten : Form
    {
        private string connectionString = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public BestellungBearbeiten()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void BestellungBearbeiten_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            populatedatagridview(); 
        }
        private void populatedatagridview()
        {
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("Select Bestellung_id, Franchise_id, Status_id, Datum from Bestellung", con);
                ada.Fill(ds, "Bestellung");
                dgbearbeiten.DataSource = ds;
                dgbearbeiten.DataMember = "Bestellung";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedrow = dgbearbeiten.Rows[e.RowIndex];
                BearbeitenBestellung bearbeiten = new BearbeitenBestellung(selectedrow, connectionString);
                openchildform(bearbeiten);
            }
        }
    }
}
