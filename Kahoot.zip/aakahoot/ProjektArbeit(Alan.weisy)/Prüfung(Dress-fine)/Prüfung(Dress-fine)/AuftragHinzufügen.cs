﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
    public partial class AuftragHinzufügen : Form
    {
        private String Connectionstring = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public AuftragHinzufügen()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void AuftragHinzufügen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Dress.accdb";
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
            try
            {
                cmd = new OleDbCommand("SELECT * FROM Status ORDER BY Status_id ASC", con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    cbx_status_id.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("SELECT * FROM Lieferanten ORDER BY Lieferant_id ASC", con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbx_lieferanten_id.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim combobox zu füllen");
            }
                con.Close();
            datagridviewfüllen();
        }
        private void datagridviewfüllen()
        {
            try
            {
                ds.Clear();
                ada = new OleDbDataAdapter("Select Auftrag_id, Status_id, Lieferant_id, Datum from Auftrag", con);
                ada.Fill(ds, "Auftrag");
                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Auftrag";
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Datagridview" + a);
            }
        }

       
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(Connectionstring))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_status_id.Text) || string.IsNullOrWhiteSpace(cbx_lieferanten_id.Text) || string.IsNullOrWhiteSpace(tbx_datum.Text)
                        )
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        using (OleDbCommand insert = new OleDbCommand("INSERT INTO Auftrag (Status_id, Lieferant_id, Datum)"
                            + "VALUES(@Status, @Lieferanten, @Datume)", con))
                        {
                            insert.Parameters.AddWithValue("@Status", Convert.ToInt32(cbx_status_id.Text));
                            insert.Parameters.AddWithValue("@Lieferanten", Convert.ToInt32(cbx_lieferanten_id.Text));
                            insert.Parameters.AddWithValue("@Datume", tbx_datum.Text);

                            insert.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Gespeichert!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        datagridviewfüllen();
                    }
                }
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim speichern" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cbx_status_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_status_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Status where Status_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_status.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Status" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cbx_lieferanten_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                int vergleich = System.Convert.ToInt32(cbx_lieferanten_id.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Lieferanten where Lieferant_id=" + vergleich, con);
                dr = cmd.ExecuteReader();

                dr.Read();
                tbx_name.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("fehler beim verbindung mit der tabelle Artikegruppen" + a, "Information Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openchildform(new AuftragpositionADD());
        }
    }
}
