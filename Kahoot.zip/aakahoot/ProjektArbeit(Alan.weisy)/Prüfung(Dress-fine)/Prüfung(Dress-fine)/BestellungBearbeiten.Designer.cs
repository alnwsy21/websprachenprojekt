﻿
namespace Prüfung_Dress_fine_
{
    partial class BestellungBearbeiten
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dgbearbeiten = new System.Windows.Forms.DataGridView();
            this.panelchildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbearbeiten)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.label1);
            this.panelchildform.Controls.Add(this.dgbearbeiten);
            this.panelchildform.Location = new System.Drawing.Point(-3, 0);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1219, 763);
            this.panelchildform.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(329, 440);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 73);
            this.label1.TabIndex = 6;
            this.label1.Text = "Bestellung";
            // 
            // dgbearbeiten
            // 
            this.dgbearbeiten.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgbearbeiten.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dgbearbeiten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbearbeiten.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dgbearbeiten.Location = new System.Drawing.Point(2, 0);
            this.dgbearbeiten.Name = "dgbearbeiten";
            this.dgbearbeiten.Size = new System.Drawing.Size(1217, 272);
            this.dgbearbeiten.TabIndex = 0;
            this.dgbearbeiten.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgbearbeiten_CellDoubleClick);
            // 
            // BestellungBearbeiten
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 767);
            this.Controls.Add(this.panelchildform);
            this.Name = "BestellungBearbeiten";
            this.Text = "BestellungBearbeiten";
            this.Load += new System.EventHandler(this.BestellungBearbeiten_Load);
            this.panelchildform.ResumeLayout(false);
            this.panelchildform.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbearbeiten)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgbearbeiten;
    }
}