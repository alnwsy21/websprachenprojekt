﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Prüfung_Dress_fine_
{
  
    public partial class BearbeitenLager : Form
    {
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdateRow { get; private set; }
        public BearbeitenLager(DataGridViewRow selectedRow, string connectionString)
        {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void BearbeitenLager_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Dress.accdb";
                AnzeigenDerDaten();
                con.Open();
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler bei der Datenbank Öffnung!:" + a);
            }
        }
        private void AnzeigenDerDaten()
        {
            try
            {
                tbx_ort.Text = selectedRow.Cells["Ort"].Value.ToString();
                tbx_kap.Text = selectedRow.Cells["Kapazität"].Value.ToString();
          
            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler beim anzeigen der daten!" + a, "Infrmation Fehler", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void btnbewegungsdaten_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(tbx_ort.Text) || string.IsNullOrWhiteSpace(tbx_kap.Text)
                     )
                    {
                        MessageBox.Show("Bitte füllen sie alle Felder aus!", "Fehlende information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string query = "UPDATE Lager SET Ort = ?, Kapazität = ? WHERE Lager_id = ?";
                        using (OleDbCommand Insertcmd = new OleDbCommand(query, con))
                        {
                            Insertcmd.Parameters.AddWithValue("@Ort", tbx_ort.Text);
                            Insertcmd.Parameters.AddWithValue("@Kapazität", Convert.ToInt32(tbx_kap.Text));
                           
                            Insertcmd.Parameters.AddWithValue("@Lager_id", selectedRow.Cells["Lager_id"].Value);
                            Insertcmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich Bearbeitet!");
                        UpdateRow = selectedRow;
                    }
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler Beim Bearbeiten!" + a, "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
