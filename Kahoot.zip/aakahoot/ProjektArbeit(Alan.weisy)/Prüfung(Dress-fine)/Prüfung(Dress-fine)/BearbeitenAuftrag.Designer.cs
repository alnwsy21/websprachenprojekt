﻿
namespace Prüfung_Dress_fine_
{
    partial class BearbeitenAuftrag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbewegungsdaten = new System.Windows.Forms.Button();
            this.tbx_datum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbx_name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbx_lieferanten_id = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_status = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbx_status_id = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnbewegungsdaten
            // 
            this.btnbewegungsdaten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbewegungsdaten.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbewegungsdaten.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnbewegungsdaten.Location = new System.Drawing.Point(0, 543);
            this.btnbewegungsdaten.Name = "btnbewegungsdaten";
            this.btnbewegungsdaten.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnbewegungsdaten.Size = new System.Drawing.Size(1219, 221);
            this.btnbewegungsdaten.TabIndex = 34;
            this.btnbewegungsdaten.Text = "Bearbeiten";
            this.btnbewegungsdaten.UseVisualStyleBackColor = true;
            this.btnbewegungsdaten.Click += new System.EventHandler(this.btnbewegungsdaten_Click);
            // 
            // tbx_datum
            // 
            this.tbx_datum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_datum.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_datum.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_datum.Location = new System.Drawing.Point(941, 251);
            this.tbx_datum.Multiline = true;
            this.tbx_datum.Name = "tbx_datum";
            this.tbx_datum.Size = new System.Drawing.Size(190, 34);
            this.tbx_datum.TabIndex = 44;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(866, 251);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 24);
            this.label4.TabIndex = 43;
            this.label4.Text = "Datum:";
            // 
            // tbx_name
            // 
            this.tbx_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_name.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_name.Location = new System.Drawing.Point(647, 275);
            this.tbx_name.Multiline = true;
            this.tbx_name.Name = "tbx_name";
            this.tbx_name.Size = new System.Drawing.Size(190, 34);
            this.tbx_name.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(535, 275);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 24);
            this.label1.TabIndex = 41;
            this.label1.Text = "Name:";
            // 
            // cbx_lieferanten_id
            // 
            this.cbx_lieferanten_id.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_lieferanten_id.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_lieferanten_id.FormattingEnabled = true;
            this.cbx_lieferanten_id.Location = new System.Drawing.Point(647, 254);
            this.cbx_lieferanten_id.Name = "cbx_lieferanten_id";
            this.cbx_lieferanten_id.Size = new System.Drawing.Size(190, 21);
            this.cbx_lieferanten_id.TabIndex = 40;
            this.cbx_lieferanten_id.SelectedIndexChanged += new System.EventHandler(this.cbx_lieferanten_id_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(471, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 24);
            this.label3.TabIndex = 39;
            this.label3.Text = "Lieferanten ID:";
            // 
            // tbx_status
            // 
            this.tbx_status.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_status.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_status.Location = new System.Drawing.Point(240, 276);
            this.tbx_status.Multiline = true;
            this.tbx_status.Name = "tbx_status";
            this.tbx_status.Size = new System.Drawing.Size(190, 34);
            this.tbx_status.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(107, 277);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 24);
            this.label6.TabIndex = 37;
            this.label6.Text = "Bezeichnung:";
            // 
            // cbx_status_id
            // 
            this.cbx_status_id.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_status_id.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_status_id.FormattingEnabled = true;
            this.cbx_status_id.Location = new System.Drawing.Point(240, 256);
            this.cbx_status_id.Name = "cbx_status_id";
            this.cbx_status_id.Size = new System.Drawing.Size(190, 21);
            this.cbx_status_id.TabIndex = 36;
            this.cbx_status_id.SelectedIndexChanged += new System.EventHandler(this.cbx_status_id_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(81, 251);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 24);
            this.label5.TabIndex = 35;
            this.label5.Text = "Status ID:";
            // 
            // BearbeitenAuftrag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1219, 763);
            this.Controls.Add(this.tbx_datum);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbx_name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbx_lieferanten_id);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbx_status);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbx_status_id);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnbewegungsdaten);
            this.Name = "BearbeitenAuftrag";
            this.Text = "BearbeitenAuftrag";
            this.Load += new System.EventHandler(this.BearbeitenAuftrag_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbewegungsdaten;
        private System.Windows.Forms.TextBox tbx_datum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbx_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbx_lieferanten_id;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbx_status;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbx_status_id;
        private System.Windows.Forms.Label label5;
    }
}