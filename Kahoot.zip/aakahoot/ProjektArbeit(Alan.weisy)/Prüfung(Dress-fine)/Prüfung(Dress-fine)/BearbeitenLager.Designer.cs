﻿
namespace Prüfung_Dress_fine_
{
    partial class BearbeitenLager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_kap = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbx_ort = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnbewegungsdaten = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbx_kap
            // 
            this.tbx_kap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_kap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_kap.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_kap.Location = new System.Drawing.Point(530, 367);
            this.tbx_kap.Multiline = true;
            this.tbx_kap.Name = "tbx_kap";
            this.tbx_kap.Size = new System.Drawing.Size(182, 35);
            this.tbx_kap.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(330, 371);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 24);
            this.label6.TabIndex = 27;
            this.label6.Text = "Lager Kapazität:";
            // 
            // tbx_ort
            // 
            this.tbx_ort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.tbx_ort.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_ort.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_ort.Location = new System.Drawing.Point(530, 299);
            this.tbx_ort.Multiline = true;
            this.tbx_ort.Name = "tbx_ort";
            this.tbx_ort.Size = new System.Drawing.Size(182, 35);
            this.tbx_ort.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(330, 303);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 24);
            this.label5.TabIndex = 25;
            this.label5.Text = "Lager Ort:";
            // 
            // btnbewegungsdaten
            // 
            this.btnbewegungsdaten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbewegungsdaten.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbewegungsdaten.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnbewegungsdaten.Location = new System.Drawing.Point(0, 613);
            this.btnbewegungsdaten.Name = "btnbewegungsdaten";
            this.btnbewegungsdaten.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnbewegungsdaten.Size = new System.Drawing.Size(1044, 88);
            this.btnbewegungsdaten.TabIndex = 29;
            this.btnbewegungsdaten.Text = "Bearbeiten";
            this.btnbewegungsdaten.UseVisualStyleBackColor = true;
            this.btnbewegungsdaten.Click += new System.EventHandler(this.btnbewegungsdaten_Click);
            // 
            // BearbeitenLager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1043, 700);
            this.Controls.Add(this.btnbewegungsdaten);
            this.Controls.Add(this.tbx_kap);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbx_ort);
            this.Controls.Add(this.label5);
            this.Name = "BearbeitenLager";
            this.Text = "BearbeitenLager";
            this.Load += new System.EventHandler(this.BearbeitenLager_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_kap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbx_ort;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnbewegungsdaten;
    }
}